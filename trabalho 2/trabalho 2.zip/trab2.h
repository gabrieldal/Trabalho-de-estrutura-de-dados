struct aluno;
void print_node(struct aluno *head);
struct aluno *ordem_alfab(struct aluno *head);
struct aluno *deletar(struct aluno *head);